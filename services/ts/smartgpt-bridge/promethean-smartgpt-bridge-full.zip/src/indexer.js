import fs from 'fs/promises';
import path from 'path';
import fg from 'fast-glob';
import { ChromaClient } from 'chromadb';
import { RemoteEmbeddingFunction } from './remoteEmbedding.js';

const chroma = new ChromaClient();

function splitCSV(s){ return (s||'').split(',').map(x=>x.trim()).filter(Boolean); }
function defaultExcludes(){
  const env = splitCSV(process.env.EXCLUDE_GLOBS);
  return env.length ? env : ['node_modules/**','.git/**','dist/**','build/**','.obsidian/**'];
}

// Chunk by ~2000 chars with 200 overlap; track line numbers.
function makeChunks(text, maxLen=2000, overlap=200){
  const chunks=[]; let i=0; let start=0;
  while(start<text.length){
    const end=Math.min(text.length,start+maxLen);
    const chunk=text.slice(start,end);
    const startLine=text.slice(0,start).split('\n').length;
    const endLine=text.slice(0,end).split('\n').length;
    chunks.push({index:i++,start,end,startLine,endLine,text:chunk});
    if(end===text.length) break;
    start=end-overlap;
  }
  return chunks;
}

export async function buildEmbeddingFn(){
  const driver=process.env.EMBEDDING_DRIVER||'ollama';
  const fn=process.env.EMBEDDING_FUNCTION||'nomic-embed-text';
  return RemoteEmbeddingFunction.fromConfig({driver,fn});
}

export async function collectionForFamily(family,version,cfg){
  return await chroma.getOrCreateCollection({
    name: `${family}__${version}__${cfg.driver}__${cfg.fn}`,
    embeddingFunction: await buildEmbeddingFn(),
    metadata: {family,version,...cfg}
  });
}

export async function reindexAll(rootPath, options={}){
  const family = process.env.COLLECTION_FAMILY || 'repo_files';
  const version = process.env.EMBED_VERSION || 'dev';
  const include = options.include || ['**/*.{md,txt,js,ts,jsx,tsx,py,go,rs,json,yml,yaml,sh}'];
  const exclude = options.exclude || defaultExcludes();
  const limit = options.limit || 0;
  const cfg={ driver:process.env.EMBEDDING_DRIVER||'ollama', fn:process.env.EMBEDDING_FUNCTION||'nomic-embed-text', dims:Number(process.env.EMBED_DIMS||768)};
  const col=await collectionForFamily(family,version,cfg);
  const files = await fg(include,{cwd:rootPath,ignore:exclude,onlyFiles:true,dot:false});
  const max = limit>0?Math.min(limit,files.length):files.length;
  let processed=0;
  for(let i=0;i<max;i++){
    const rel=files[i]; const abs=path.join(rootPath,rel);
    const raw=await fs.readFile(abs,'utf8');
    const chunks=makeChunks(raw);
    for(const c of chunks){
      const id=`${rel}#${c.index}`;
      await col.upsert({
        ids:[id],
        documents:[c.text],
        metadatas:[{path:rel,chunkIndex:c.index,startLine:c.startLine,endLine:c.endLine,bytesStart:c.start,bytesEnd:c.end,version,driver:cfg.driver,fn:cfg.fn}]
      });
      processed++;
    }
  }
  return {family,version,processed};
}

export async function reindexSubset(rootPath, globs, options={}){
  const include = Array.isArray(globs)?globs:[String(globs)];
  const merged = {...options, include};
  return reindexAll(rootPath, merged);
}

export async function search(rootPath, q, n=8){
  const family=process.env.COLLECTION_FAMILY||'repo_files';
  const version=process.env.EMBED_VERSION||'dev';
  const cfg={driver:process.env.EMBEDDING_DRIVER||'ollama', fn:process.env.EMBEDDING_FUNCTION||'nomic-embed-text'};
  const col=await collectionForFamily(family,version,cfg);
  const r=await col.query({queryTexts:[q], nResults:n});
  const ids=r.ids?.flat(2)||[];
  const docs=r.documents?.flat(2)||[];
  const metas=r.metadatas?.flat(2)||[];
  const dists=r.distances?.flat(2)||[];
  const out=[];
  for(let i=0;i<docs.length;i++){
    const m=metas[i]||{};
    out.push({ id:ids[i], path:m.path, chunkIndex:m.chunkIndex, startLine:m.startLine, endLine:m.endLine, score: typeof dists[i]==='number'?dists[i]:undefined, text:docs[i] });
  }
  return out;
}
