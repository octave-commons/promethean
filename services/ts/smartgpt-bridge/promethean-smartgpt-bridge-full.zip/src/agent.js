import { spawn } from 'child_process';
import { nanoid } from 'nanoid';

const ROOT_PATH = process.env.ROOT_PATH || process.cwd();
const CODEX_BIN = process.env.CODEX_BIN || 'codex';
const DEFAULT_ARGS = (process.env.CODEX_ARGS || '').split(' ').filter(Boolean);
const MAX_LOG_BYTES = Number(process.env.AGENT_MAX_LOG_BYTES || 512*1024);
const USE_SHELL = /^true$/i.test(process.env.AGENT_SHELL || 'false');

const DANGER_PATTERNS = [
  /rm\s+-rf\s+\/(?!home)/i,
  /\bDROP\s+DATABASE\b/i,
  /\bmkfs\w*\s+\/dev\//i,
  /\bshutdown\b|\breboot\b/i,
  /\bchmod\s+777\b/i
];

function ringPush(buf, chunk){
  const slice = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk));
  const combined = Buffer.concat([buf, slice]);
  if (combined.length <= MAX_LOG_BYTES) return combined;
  return combined.subarray(combined.length - MAX_LOG_BYTES);
}
function matchDanger(s){ return DANGER_PATTERNS.find(rx => rx.test(s)); }

export class AgentSupervisor {
  constructor(){
    this.procs = new Map();
    this.subscribers = new Map();
  }
  list(){
    return Array.from(this.procs.values()).map(p=>({
      id:p.id, cmd:p.cmd, args:p.args, cwd:p.cwd, startedAt:p.startedAt,
      exited:p.exited, code:p.code, signal:p.signal, paused_by_guard:p.paused_by_guard, bytes:p.log.length
    }));
  }
  status(id){
    const p=this.procs.get(id); if(!p) return null;
    return { id:p.id, cmd:p.cmd, args:p.args, cwd:p.cwd, startedAt:p.startedAt,
      exited:p.exited, code:p.code, signal:p.signal, paused_by_guard:p.paused_by_guard, bytes:p.log.length };
  }
  logs(id,since=0){
    const p=this.procs.get(id); if(!p) return null;
    const buf=p.log; const from=Math.max(0,Math.min(since,buf.length));
    return { total: buf.length, chunk: buf.subarray(from).toString('utf8') };
  }
  _broadcast(id,event,data){
    const subs=this.subscribers.get(id); if(!subs) return;
    const payload=`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    for(const res of subs){ res.write(payload); }
  }
  stream(id,res){
    res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});
    if(!this.subscribers.has(id)) this.subscribers.set(id,new Set());
    this.subscribers.get(id).add(res);
    res.write(`event: hello\ndata: ${JSON.stringify({id})}\n\n`);
    res.on('close',()=>{ const set=this.subscribers.get(id); if(set){ set.delete(res); if(!set.size) this.subscribers.delete(id); } });
  }
  start({prompt,args=[],cwd=ROOT_PATH,env={},auto=true}){
    const id=nanoid();
    const fullArgs=[...DEFAULT_ARGS,...args];
    const proc=spawn(CODEX_BIN,fullArgs,{cwd,env:{...process.env,...env},shell:USE_SHELL,stdio:['pipe','pipe','pipe']});
    const state={ id, cmd:CODEX_BIN, args:fullArgs, cwd, startedAt:Date.now(), exited:false, code:null, signal:null, paused_by_guard:false, log:Buffer.alloc(0), proc };
    this.procs.set(id,state);
    const onData=(data,stream)=>{
      state.log=ringPush(state.log,data);
      const text=data.toString('utf8');
      this._broadcast(id,stream,{text});
      const m=matchDanger(text);
      if(m && !state.paused_by_guard){
        try{ process.kill(proc.pid,'SIGSTOP'); state.paused_by_guard=true; }catch{}
        this._broadcast(id,'guard',{paused:true,reason:m.source});
      }
    };
    proc.stdout.on('data',d=>onData(d,'stdout'));
    proc.stderr.on('data',d=>onData(d,'stderr'));
    proc.on('exit',(code,signal)=>{ state.exited=true; state.code=code; state.signal=signal; this._broadcast(id,'exit',{code,signal}); });
    if(prompt){ try{ proc.stdin.write(String(prompt).trim()+"\n"); }catch{} }
    return { id, pid:proc.pid };
  }
  send(id,input){ const p=this.procs.get(id); if(!p||p.exited) return false; try{ p.proc.stdin.write(String(input)+"\n"); return true; }catch{ return false; } }
  interrupt(id){ const p=this.procs.get(id); if(!p||p.exited) return false; try{ process.kill(p.proc.pid,'SIGINT'); return true; }catch{ return false; } }
  kill(id,force=false){ const p=this.procs.get(id); if(!p||p.exited) return false; try{ process.kill(p.proc.pid, force?'SIGKILL':'SIGTERM'); return true; }catch{ return false; } }
  resume(id){ const p=this.procs.get(id); if(!p||!p.paused_by_guard) return false; try{ process.kill(p.proc.pid,'SIGCONT'); p.paused_by_guard=false; this._broadcast(id,'guard',{paused:false}); return true; }catch{ return false; } }
}
export const supervisor = new AgentSupervisor();
