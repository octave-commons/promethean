import express from 'express';
import { reindexAll, reindexSubset, search } from './indexer.js';
import { grep } from './grep.js';
import { viewFile, locateStacktrace } from './files.js';
import { symbolsIndex, symbolsFind } from './symbols.js';
import { supervisor } from './agent.js';

const ROOT_PATH = process.env.ROOT_PATH;
if (!ROOT_PATH) {
  console.error("Set ROOT_PATH to your repo/docs root.");
  process.exit(1);
}

function spec(){
  return {
    openapi: "3.0.0",
    info: { title: "Promethean SmartGPT Bridge (Full)", version: "1.0.0" },
    paths: {
      "/reindex": { post: { summary: "Reindex entire ROOT_PATH" } },
      "/files/reindex": { post: { summary: "Reindex subset by glob(s)" } },
      "/search": { post: { summary: "Semantic search via Chroma" } },
      "/grep": { post: { summary: "Regex search across files" } },
      "/files/view": { get: { summary: "View file snippet around a line" } },
      "/stacktrace/locate": { post: { summary: "Parse stacktrace -> snippets" } },
      "/symbols/index": { post: { summary: "Index TS/JS symbols" } },
      "/symbols/find": { post: { summary: "Find symbols" } },
      "/agent/start": { post: { summary: "Start codex agent with super-prompt" } },
      "/agent/status": { get: { summary: "Get agent status" } },
      "/agent/list": { get: { summary: "List agents" } },
      "/agent/logs": { get: { summary: "Get logs (since offset)" } },
      "/agent/stream": { get: { summary: "SSE live logs" } },
      "/agent/send": { post: { summary: "Send input to stdin" } },
      "/agent/interrupt": { post: { summary: "SIGINT" } },
      "/agent/kill": { post: { summary: "SIGTERM/SIGKILL" } },
      "/agent/resume": { post: { summary: "Resume after guard pause" } }
    }
  };
}

const app = express();
app.use(express.json({ limit: "10mb" }));

app.get("/openapi.json", (_req,res)=> res.json(spec()));

// Indexing / Search
app.post("/reindex", async (req,res)=>{
  try { const { limit } = req.body||{}; const r=await reindexAll(ROOT_PATH,{limit}); res.json({ok:true,...r}); }
  catch(e){ res.status(500).json({ok:false,error:String(e?.message||e)}); }
});
app.post("/files/reindex", async (req,res)=>{
  try { const globs=req.body?.path ?? req.query?.path; if(!globs) return res.status(400).json({ok:false,error:"Missing 'path'"});
    const r=await reindexSubset(ROOT_PATH, globs, {}); res.json({ok:true,...r}); }
  catch(e){ res.status(500).json({ok:false,error:String(e?.message||e)}); }
});
app.post("/search", async (req,res)=>{
  try { const { q, n } = req.body||{}; if(!q) return res.status(400).json({ok:false,error:"Missing 'q'"});
    const results=await search(ROOT_PATH, q, n??8); res.json({ok:true,results}); }
  catch(e){ res.status(500).json({ok:false,error:String(e?.message||e)}); }
});

// Grep
app.post("/grep", async (req,res)=>{
  try { const body=req.body||{}; const results=await grep(ROOT_PATH, { pattern:body.pattern, flags:body.flags||'g', paths: body.paths || ['**/*.{ts,tsx,js,jsx,py,go,rs,md,txt,json,yml,yaml,sh}'], maxMatches: body.maxMatches ?? 200, context: body.context ?? 2 });
    res.json({ok:true,results}); }
  catch(e){ res.status(400).json({ok:false,error:String(e?.message||e)}); }
});

// Files / Stacktrace
app.get("/files/view", async (req,res)=>{
  try { const p=req.query?.path; const line=Number(req.query?.line||1); const context=Number(req.query?.context||25);
    const out=await viewFile(ROOT_PATH, String(p||''), line, context); res.json({ok:true, ...out}); }
  catch(e){ res.status(404).json({ok:false,error:String(e?.message||e)}); }
});
app.post("/stacktrace/locate", async (req,res)=>{
  try { const { text, context } = req.body||{}; const out=await locateStacktrace(ROOT_PATH, String(text||''), Number(context||25)); res.json({ok:true, results: out}); }
  catch(e){ res.status(400).json({ok:false,error:String(e?.message||e)}); }
});

// Symbols
app.post("/symbols/index", async (req,res)=>{
  try { const { paths, exclude } = req.body||{}; const info=await symbolsIndex(ROOT_PATH,{ paths, exclude }); res.json({ok:true, indexed: info, info}); }
  catch(e){ res.status(500).json({ok:false,error:String(e?.message||e)}); }
});
app.post("/symbols/find", async (req,res)=>{
  try { const { query, kind, path: p, limit } = req.body||{}; const out=await symbolsFind(query, { kind, path: p, limit }); res.json({ok:true, results: out}); }
  catch(e){ res.status(400).json({ok:false,error:String(e?.message||e)}); }
});

// Agent
app.post("/agent/start", (req,res)=>{
  try { const { prompt, args, cwd, env, auto } = req.body||{}; const out=supervisor.start({prompt,args,cwd,env,auto}); res.json({ok:true,...out}); }
  catch(e){ res.status(500).json({ok:false,error:String(e?.message||e)}); }
});
app.get("/agent/status", (req,res)=>{
  const id=String(req.query?.id||''); const st=supervisor.status(id); if(!st) return res.status(404).json({ok:false,error:'not found'}); res.json({ok:true,status:st});
});
app.get("/agent/list", (_req,res)=> res.json({ok:true, agents: supervisor.list()}));
app.get("/agent/logs", (req,res)=>{
  const id=String(req.query?.id||''); const since=Number(req.query?.since||0); const logs=supervisor.logs(id,since);
  if(!logs) return res.status(404).json({ok:false,error:'not found'}); res.json({ok:true,total:logs.total,chunk:logs.chunk});
});
app.get("/agent/stream", (req,res)=>{
  const id=String(req.query?.id||''); if(!id) return res.status(400).end(); supervisor.stream(id,res);
});
app.post("/agent/send", (req,res)=>{
  const { id, input } = req.body||{}; if(!id) return res.status(400).json({ok:false,error:'missing id'}); const ok=supervisor.send(String(id), String(input ?? "")); res.json({ok});
});
app.post("/agent/interrupt", (req,res)=>{ const { id } = req.body||{}; const ok=supervisor.interrupt(String(id||'')); res.json({ok}); });
app.post("/agent/kill", (req,res)=>{ const { id, force } = req.body||{}; const ok=supervisor.kill(String(id||''), Boolean(force)); res.json({ok}); });
app.post("/agent/resume", (req,res)=>{ const { id } = req.body||{}; const ok=supervisor.resume(String(id||'')); res.json({ok}); });

const PORT=Number(process.env.PORT||3210);
const HOST=process.env.HOST||'0.0.0.0';
app.listen(PORT,HOST,()=>{ console.log(`Bridge listening on http://${HOST}:${PORT}`); console.log(`ROOT_PATH=${ROOT_PATH}`); });
