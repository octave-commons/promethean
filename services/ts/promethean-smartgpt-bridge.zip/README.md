# Promethean SmartGPT Bridge

A tiny HTTP bridge that lets a **Custom GPT** access your code/docs via **Chroma** using your
Promethean **RemoteEmbeddingFunction** (broker-driven). No Smart Connect, no Smart ENV.

## Features
- Walk & chunk files under `ROOT_PATH` (repo or `/docs`), ignoring `node_modules`, `.git`, etc.
- Upsert embeddings into Chroma using your **RemoteEmbeddingFunction**.
- Serve **/openapi.json** for Custom GPT import; works with **Tailscale Funnel**.
- Endpoints:
  - `POST /reindex` — reindex everything
  - `POST /files/reindex` — reindex subset (by `path` glob)
  - `POST /search` — semantic search (returns file path + chunk index + line range)

## Quick Start
```bash
npm i
export ROOT_PATH=/home/err/devel/promethean/docs     # or /home/err/devel/promethean
export AGENT_NAME=Duck
export BROKER_URL=ws://localhost:7000
export EMBEDDING_DRIVER=ollama
export EMBEDDING_FUNCTION=nomic-embed-text
export EMBED_DIMS=768
export EXCLUDE_GLOBS="node_modules/**,.git/**,dist/**,build/**,.obsidian/**"

# one-shot index
npm run reindex

# run API
npm start
# -> http://0.0.0.0:3210/openapi.json
```

## API
- `GET /openapi.json`
- `POST /reindex` → `{ "limit"?: number }`
- `POST /files/reindex` → body `{ "path": "<glob or array of globs>" }` or query `?path=<glob>`
- `POST /search` → `{ "q": "string", "n"?: number }`

### Search Response
Includes file and offset metadata:
```json
{
  "ok": true,
  "results": [
    {
      "id": "path#chunkIndex",
      "path": "src/foo.ts",
      "chunkIndex": 3,
      "startLine": 120,
      "endLine": 170,
      "score": 0.123,
      "text": "…chunk text…"
    }
  ]
}
```

## Funnel
```bash
sudo tailscale funnel 3210
# Import https://<your>.ts.net/openapi.json into a Custom GPT
```
