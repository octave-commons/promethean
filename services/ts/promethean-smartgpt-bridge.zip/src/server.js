import express from 'express';
import { reindexAll, reindexSubset, search } from './indexer.js';

function spec() {
  return {
    openapi: "3.0.0",
    info: { title: "Promethean SmartGPT Bridge", version: "0.2.0" },
    paths: {
      "/reindex": {
        post: {
          summary: "Reindex entire ROOT_PATH",
          requestBody: { content: { "application/json": { schema: {
            type:"object", properties:{ limit:{type:"integer"} }
          }}}},
          responses: { "200": { description: "OK" } }
        }
      },
      "/files/reindex": {
        post: {
          summary: "Reindex subset of files by glob(s) relative to ROOT_PATH",
          requestBody: { content: { "application/json": { schema: {
            type:"object", properties:{ path:{oneOf:[{type:"string"},{type:"array", items:{type:"string"}}]} }, required:["path"]
          }}}},
          responses: { "200": { description: "OK" } }
        }
      },
      "/search": {
        post: {
          summary: "Semantic search",
          requestBody: { content: { "application/json": { schema: {
            type:"object", properties:{ q:{type:"string"}, n:{type:"integer"} }, required:["q"]
          }}}},
          responses: { "200": { description: "OK" } }
        }
      }
    }
  };
}

const ROOT_PATH = process.env.ROOT_PATH;
if (!ROOT_PATH) {
  console.error("Set ROOT_PATH to your repo/docs root.");
  process.exit(1);
}

const app = express();
app.use(express.json({ limit: "10mb" }));

app.get("/openapi.json", (_req, res) => res.json(spec()));

app.post("/reindex", async (req, res) => {
  try {
    const { limit } = req.body || {};
    const r = await reindexAll(ROOT_PATH, { limit });
    res.json({ ok:true, ...r });
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e?.message || e) });
  }
});

app.post("/files/reindex", async (req, res) => {
  try {
    const bodyPath = req.body?.path;
    const queryPath = req.query?.path;
    const globs = bodyPath ?? queryPath;
    if (!globs) return res.status(400).json({ ok:false, error: "Missing 'path' (glob or array)" });
    const r = await reindexSubset(ROOT_PATH, globs, {});
    res.json({ ok:true, ...r });
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e?.message || e) });
  }
});

app.post("/search", async (req, res) => {
  try {
    const { q, n } = req.body || {};
    if (!q) return res.status(400).json({ ok:false, error: "Missing 'q'" });
    const results = await search(ROOT_PATH, q, n ?? 8);
    res.json({ ok:true, results });
  } catch (e) {
    res.status(500).json({ ok:false, error: String(e?.message || e) });
  }
});

const PORT = Number(process.env.PORT || 3210);
const HOST = process.env.HOST || "0.0.0.0";

app.listen(PORT, HOST, () => {
  console.log(`Bridge listening on http://${HOST}:${PORT}`);
  console.log(`ROOT_PATH=${ROOT_PATH}`);
});
